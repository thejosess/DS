package S1;

public abstract class FactoriaCarreraYBicicleta {

	public abstract Bicicleta crearBicicleta();

	public abstract Carrera crearCarrera();

}