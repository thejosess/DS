package S1;

public class BiciMontana extends Bicicleta {

    BiciMontana(){
        super();
    }
    
    @Override
    String getTipo() {
        return "Montaña";
    }
}