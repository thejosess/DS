package S1;

public class BiciCarretera extends Bicicleta {

    BiciCarretera(){
        super();
    }

    @Override
    String getTipo() {
        return "Carretera";
    }
}